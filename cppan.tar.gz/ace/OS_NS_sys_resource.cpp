#include "ace/OS_NS_sys_resource.h"

#if !defined (ACE_HAS_INLINED_OSCALLS)
# include "ace/OS_NS_sys_resource.inl"
#endif /* ACE_HAS_INLINED_OSCALLS */

