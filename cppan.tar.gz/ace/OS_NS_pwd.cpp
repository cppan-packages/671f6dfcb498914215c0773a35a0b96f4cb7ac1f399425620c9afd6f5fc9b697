#include "ace/OS_NS_pwd.h"

#if !defined (ACE_HAS_INLINED_OSCALLS)
# include "ace/OS_NS_pwd.inl"
#endif /* ACE_HAS_INLINED_OSCALLS */

