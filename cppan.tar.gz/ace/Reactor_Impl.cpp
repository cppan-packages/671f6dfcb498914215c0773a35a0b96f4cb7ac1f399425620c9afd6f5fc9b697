#include "ace/Reactor_Impl.h"

ACE_BEGIN_VERSIONED_NAMESPACE_DECL

ACE_ALLOC_HOOK_DEFINE (ACE_Reactor_Impl)

ACE_Reactor_Impl::~ACE_Reactor_Impl (void)
{
}

ACE_END_VERSIONED_NAMESPACE_DECL
